import 'package:flutter/material.dart';

import '../models/record.dart';
import '../services/app_store.dart';

const blue = Color(0xFF2463F5);
const ink = Color(0xFF172033);
const muted = Color(0xFF61738E);
const canvas = Color(0xFFF6F7F9);
final store = AppStore.instance;
void message(BuildContext context, String text) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
Future<void> perform(
  BuildContext context,
  Future<dynamic> Function() action, [
  String success = 'Đã lưu lên Firebase',
]) async {
  // Dialog chặn bấm lặp và không cho rời màn hình khi thao tác đang chờ server.
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const PopScope(
      canPop: false,
      child: Center(child: CircularProgressIndicator()),
    ),
  );
  try {
    await action();
    if (context.mounted) {
      Navigator.of(context, rootNavigator: true).pop();
      message(context, success);
    }
  } catch (e) {
    if (context.mounted) {
      Navigator.of(context, rootNavigator: true).pop();
      message(context, errorText(e));
    }
  }
}

Future<bool> confirm(BuildContext context, String text) async =>
    await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Xác nhận'),
        content: Text(text),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Quay lại'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Đồng ý'),
          ),
        ],
      ),
    ) ??
    false;
Future<void> openPage(BuildContext context, Widget page) =>
    Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => page));
Widget box(Widget child) => Card(
  margin: const EdgeInsets.only(bottom: 12),
  child: Padding(padding: const EdgeInsets.all(16), child: child),
);
Widget info(String title, String value) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 7),
  child: Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Expanded(
        child: Text(title, style: const TextStyle(color: muted)),
      ),
      Expanded(
        child: Text(
          value.isEmpty ? 'Chưa cập nhật' : value,
          textAlign: TextAlign.right,
        ),
      ),
    ],
  ),
);
Widget empty(String text) => Padding(
  padding: const EdgeInsets.all(24),
  child: Center(child: Text(text, textAlign: TextAlign.center)),
);

class RecordsView extends StatefulWidget {
  final String collection;
  final String? field;
  final Object? equals;
  final Widget Function(BuildContext, List<Record>) builder;
  const RecordsView({
    super.key,
    required this.collection,
    required this.builder,
    this.field,
    this.equals,
  });
  @override
  State<RecordsView> createState() => _RecordsViewState();
}

class _RecordsViewState extends State<RecordsView> {
  late Stream<List<Record>> stream;
  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    stream = store.watch(
      widget.collection,
      field: widget.field,
      equals: widget.equals,
    );
  }

  @override
  void didUpdateWidget(covariant RecordsView old) {
    super.didUpdateWidget(old);
    if (old.collection != widget.collection ||
        old.field != widget.field ||
        old.equals != widget.equals)
      _load();
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Record>>(
    stream: stream,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            empty(errorText(snapshot.error)),
            TextButton(
              onPressed: () => setState(_load),
              child: const Text('Thử lại'),
            ),
          ],
        );
      if (!snapshot.hasData)
        return const Center(child: CircularProgressIndicator());
      return widget.builder(context, snapshot.data!);
    },
  );
}

class DocumentView extends StatefulWidget {
  final String collection, id;
  final Widget Function(Record) builder;
  const DocumentView({
    super.key,
    required this.collection,
    required this.id,
    required this.builder,
  });
  @override
  State<DocumentView> createState() => _DocumentViewState();
}

class _DocumentViewState extends State<DocumentView> {
  late Stream<Record?> stream;
  @override
  void initState() {
    super.initState();
    stream = store.document(widget.collection, widget.id);
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<Record?>(
    stream: stream,
    builder: (_, s) {
      if (s.hasError) return empty(errorText(s.error));
      if (s.connectionState == ConnectionState.waiting)
        return const Center(child: CircularProgressIndicator());
      if (s.data == null || s.data!.archived)
        return empty('Bản ghi không tồn tại hoặc đã lưu trữ');
      return widget.builder(s.data!);
    },
  );
}

class FieldSpec {
  final String key, title;
  final bool required, number, decimal, readOnly;
  final num? min, max;
  final Map<String, String>? options;
  const FieldSpec(
    this.key,
    this.title, {
    this.required = true,
    this.number = false,
    this.decimal = false,
    this.readOnly = false,
    this.min,
    this.max,
    this.options,
  });
}

class EditForm extends StatefulWidget {
  final String title, action;
  final bool embedded;
  final String? id;
  final Map<String, dynamic> initial;
  final List<FieldSpec> fields;
  final Map<String, dynamic> fixed;
  const EditForm({
    super.key,
    required this.title,
    required this.action,
    required this.fields,
    this.id,
    this.initial = const {},
    this.fixed = const {},
    this.embedded = false,
  });
  @override
  State<EditForm> createState() => _EditFormState();
}

class _EditFormState extends State<EditForm> {
  final key = GlobalKey<FormState>();
  final controllers = <String, TextEditingController>{};
  final selected = <String, String?>{};
  bool saving = false;
  late final String recordId;
  @override
  void initState() {
    super.initState();
    recordId = widget.id ?? store.db.collection('_').doc().id;
    for (final f in widget.fields) {
      final value = widget.initial[f.key]?.toString() ?? '';
      if (f.options != null)
        selected[f.key] = f.options!.containsKey(value) ? value : null;
      else
        controllers[f.key] = TextEditingController(text: value);
    }
  }

  @override
  void didUpdateWidget(covariant EditForm oldWidget) {
    super.didUpdateWidget(oldWidget);
    for (final f in widget.fields) {
      if (f.options != null && !f.options!.containsKey(selected[f.key])) {
        selected[f.key] = null;
      }
    }
  }

  @override
  void dispose() {
    for (final c in controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (saving || !key.currentState!.validate()) return;
    final data = <String, dynamic>{...widget.fixed};
    for (final f in widget.fields) {
      final text = (controllers[f.key]?.text ?? selected[f.key] ?? '').trim();
      data[f.key] = f.number
          ? (text.isEmpty ? 0 : num.parse(text.replaceAll(',', '.')))
          : text;
    }
    setState(() => saving = true);
    try {
      await store.command(widget.action, id: recordId, data: data);
      if (mounted) {
        Navigator.pop(context);
        message(context, 'Đã lưu lên Firebase');
      }
    } catch (e) {
      if (mounted) message(context, errorText(e));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !saving,
    child: Scaffold(
      appBar: widget.embedded ? null : AppBar(title: Text(widget.title)),
      body: Form(
        key: key,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            for (final f in widget.fields)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: f.options != null
                    ? DropdownButtonFormField<String>(
                        key: ValueKey(
                          '${f.key}:${selected[f.key] ?? ''}:${f.options!.keys.join(',')}',
                        ),
                        initialValue: f.options!.containsKey(selected[f.key])
                            ? selected[f.key]
                            : null,
                        isExpanded: true,
                        decoration: InputDecoration(
                          labelText: f.title,
                          border: const OutlineInputBorder(),
                        ),
                        items: f.options!.entries
                            .map(
                              (e) => DropdownMenuItem(
                                value: e.key,
                                child: Text(
                                  e.value,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        validator: (v) => f.required && (v == null || v.isEmpty)
                            ? 'Vui lòng chọn ${f.title}'
                            : null,
                        onChanged: saving ? null : (v) => selected[f.key] = v,
                      )
                    : TextFormField(
                        controller: controllers[f.key],
                        readOnly: f.readOnly,
                        enabled: !saving,
                        keyboardType: f.number
                            ? TextInputType.numberWithOptions(
                                decimal: f.decimal,
                              )
                            : TextInputType.text,
                        maxLines: f.key == 'description' || f.key == 'note'
                            ? 3
                            : 1,
                        decoration: InputDecoration(
                          labelText: f.title,
                          border: const OutlineInputBorder(),
                        ),
                        validator: (value) {
                          final text = (value ?? '').trim();
                          if (text.isEmpty)
                            return f.required
                                ? 'Vui lòng nhập ${f.title}'
                                : null;
                          if (f.number) {
                            final n = num.tryParse(text.replaceAll(',', '.'));
                            if (n == null ||
                                !n.isFinite ||
                                (!f.decimal && n != n.round()) ||
                                (f.min != null && n < f.min!) ||
                                (f.max != null && n > f.max!))
                              return 'Giá trị ${f.title} không hợp lệ';
                          }
                          if (f.key.endsWith('Date') &&
                              DateTime.tryParse(text) == null)
                            return 'Dùng dạng YYYY-MM-DD';
                          if (f.key == 'period' &&
                              !RegExp(r'^\d{4}-(0[1-9]|1[0-2])$')
                                  .hasMatch(text))
                            return 'Dùng dạng YYYY-MM';
                          return null;
                        },
                      ),
              ),
            FilledButton(
              onPressed: saving ? null : _save,
              child: Text(saving ? 'Đang lưu...' : 'Lưu'),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget photos(Record record) => Column(
  children: [
    for (final url in record.strings('imageUrls'))
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Image.network(
          url,
          height: 200,
          width: double.infinity,
          fit: BoxFit.cover,
          errorBuilder: (_, e, s) => empty('Không tải được ảnh'),
        ),
      ),
  ],
);
