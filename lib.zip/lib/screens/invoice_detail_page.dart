import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/record.dart';
import '../services/document_service.dart';
import '../widgets/common.dart';

class InvoiceDetailPage extends StatelessWidget {
  final String invoiceId;
  final bool landlord;
  const InvoiceDetailPage({
    super.key,
    required this.invoiceId,
    this.landlord = true,
  });
  Future<String?> _input(BuildContext context, String title) async {
    final c = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Xác nhận'),
          ),
        ],
      ),
    );
    c.dispose();
    return result;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Chi tiết hóa đơn')),
    body: DocumentView(
      collection: 'invoices',
      id: invoiceId,
      builder: (bill) {
        final bank = bill.data['bank'] is Map
            ? bill.data['bank'] as Map
            : const {};
        final lines = bill.data['lines'] as List? ?? [];
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            box(
              Column(
                children: [
                  info('Số hóa đơn', bill.text('code', bill.id)),
                  info('Phòng', bill.text('roomName')),
                  info('Người thuê', bill.text('tenantName')),
                  info('Số hợp đồng', bill.text('contractNumber')),
                  info('Kỳ tiền phòng', bill.text('period')),
                  info('Kỳ chỉ số', bill.text('meterPeriod')),
                  info('Ngày phát hành', bill.text('issueDate')),
                  info('Hạn thanh toán', bill.text('dueDate')),
                  info('Trạng thái', label(bill.text('status'))),
                ],
              ),
            ),
            box(
              Column(
                children: [
                  for (final row in lines)
                    info(
                      '${row['name']}\n${row['quantity']} × ${money(row['unitPrice'])}',
                      money(row['amount']),
                    ),
                  const Divider(),
                  info('Tổng tiền', money(bill.data['total'])),
                ],
              ),
            ),
            box(
              Column(
                children: [
                  info('Ngân hàng', '${bank['name'] ?? ''}'),
                  info('Tài khoản', '${bank['account'] ?? ''}'),
                  info('Chủ tài khoản', '${bank['holder'] ?? ''}'),
                  info('Nội dung chuyển khoản', bill.text('code', bill.id)),
                  TextButton(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(
                          text:
                              '${bank['name'] ?? ''}\n${bank['account'] ?? ''}\n${bank['holder'] ?? ''}\n${money(bill.data['total'])}\n${bill.text('code', bill.id)}',
                        ),
                      );
                      if (context.mounted)
                        message(context, 'Đã sao chép thông tin chuyển khoản');
                    },
                    child: const Text('Sao chép thông tin thanh toán'),
                  ),
                ],
              ),
            ),
            if (landlord)
              info(
                'Gửi người thuê',
                bill.text('recipientUid').isEmpty
                    ? 'Chưa liên kết tài khoản'
                    : 'Đã tạo thông báo trong hộp thư',
              ),
            if (landlord && bill.text('status') != 'void')
              OutlinedButton(
                onPressed: () => perform(
                  context,
                  () => store.command('resendInvoice', id: invoiceId),
                  'Đã gửi vào hộp thư người thuê',
                ),
                child: const Text('Gửi / gửi lại hóa đơn cho người thuê'),
              ),
            if (bill.text('status') == 'reported')
              box(
                Text(
                  'Người thuê đã báo chuyển tiền. Chủ trọ cần kiểm tra giao dịch.\n${bill.text('paymentNote')}',
                ),
              ),
            if (bill.text('status') == 'void')
              info('Lý do hủy', bill.text('voidReason')),
            OutlinedButton.icon(
              onPressed: () => perform(
                context,
                () => DocumentService.printRecord(bill, contract: false),
                'Đã mở bản in',
              ),
              icon: const Icon(Icons.print_outlined),
              label: const Text('In / lưu PDF hóa đơn'),
            ),
            if (landlord &&
                ['unpaid', 'reported'].contains(bill.text('status'))) ...[
              FilledButton(
                onPressed: () async {
                  final method = await showDialog<String>(
                    context: context,
                    builder: (c) => SimpleDialog(
                      title: const Text('Đã kiểm tra và nhận đủ tiền?'),
                      children: [
                        SimpleDialogOption(
                          onPressed: () => Navigator.pop(c, 'cash'),
                          child: const Text('Xác nhận đã nhận tiền mặt'),
                        ),
                        SimpleDialogOption(
                          onPressed: () => Navigator.pop(c, 'bank'),
                          child: const Text('Xác nhận đã nhận chuyển khoản'),
                        ),
                      ],
                    ),
                  );
                  if (method != null && context.mounted)
                    await perform(
                      context,
                      () => store.command(
                        'confirmPayment',
                        id: invoiceId,
                        args: {'method': method},
                      ),
                      'Đã xác nhận và tạo thông báo thanh toán',
                    );
                },
                child: const Text('Xác nhận đã nhận đủ tiền'),
              ),
              TextButton(
                onPressed: () async {
                  final reason = await _input(
                    context,
                    'Ghi rõ lý do hủy hóa đơn',
                  );
                  if (reason != null && reason.isNotEmpty && context.mounted)
                    await perform(
                      context,
                      () => store.command(
                        'voidInvoice',
                        id: invoiceId,
                        args: {'reason': reason},
                      ),
                    );
                },
                child: const Text(
                  'Hủy hóa đơn',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
            if (!landlord && bill.text('status') == 'unpaid')
              FilledButton(
                onPressed: () async {
                  final note = await _input(
                    context,
                    'Ghi chú giao dịch đã chuyển',
                  );
                  if (note != null && context.mounted)
                    await perform(
                      context,
                      () => store.reportPayment(invoiceId, note),
                      'Đã báo chủ trọ; đang chờ kiểm tra',
                    );
                },
                child: const Text('Tôi đã chuyển tiền – báo chủ trọ'),
              ),
          ],
        );
      },
    ),
  );
}
