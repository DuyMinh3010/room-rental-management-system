import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'tenant_edit_page.dart';
import 'tenant_detail_page.dart';

class TenantListPage extends StatefulWidget {
  const TenantListPage({super.key});
  @override
  State<TenantListPage> createState() => _TenantListPageState();
}

class _TenantListPageState extends State<TenantListPage> {
  String query = '';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Người thuê'),
      actions: [
        IconButton(
          onPressed: () => openPage(context, const TenantEditPage()),
          icon: const Icon(Icons.person_add_alt),
        ),
      ],
    ),
    body: RecordsView(
      collection: 'tenants',
      builder: (_, all) => RecordsView(
        collection: 'rooms',
        builder: (_, rooms) {
          final shown = all
              .where(
                (t) =>
                    !t.archived &&
                    '${t.name} ${t.text('phone')}'.toLowerCase().contains(
                      query.toLowerCase(),
                    ),
              )
              .toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                decoration: const InputDecoration(
                  hintText: 'Tìm tên / số điện thoại',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (v) => setState(() => query = v),
              ),
              if (shown.isEmpty) empty('Chưa có người thuê'),
              for (final t in shown)
                Card(
                  child: ListTile(
                    title: Text(t.name),
                    subtitle: Text(
                      '${t.text('phone')} · ${rooms.where((r) => r.id == t.text('roomId')).firstOrNull?.name ?? 'Chưa gán phòng'}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () =>
                        openPage(context, TenantDetailPage(tenantId: t.id)),
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}
