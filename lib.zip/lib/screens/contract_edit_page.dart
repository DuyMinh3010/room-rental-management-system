import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';

class ContractEditPage extends StatefulWidget {
  final Record? contract;
  const ContractEditPage({super.key, this.contract});
  @override
  State<ContractEditPage> createState() => _ContractEditPageState();
}

class _ContractEditPageState extends State<ContractEditPage> {
  String? roomId;
  @override
  void initState() {
    super.initState();
    roomId = widget.contract?.text('roomId');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Lập hợp đồng')),
    body: RecordsView(
      collection: 'rooms',
      builder: (_, rs) => RecordsView(
        collection: 'tenants',
        builder: (_, ts) {
          final rooms = rs
              .where((r) => !r.archived && r.condition == 'Tốt')
              .toList();
          final room = rooms.where((r) => r.id == roomId).firstOrNull;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: DropdownButtonFormField<String>(
                  initialValue: room?.id,
                  decoration: const InputDecoration(
                    labelText: 'Chọn phòng để lấy giá và người thuê',
                  ),
                  items: rooms
                      .map(
                        (r) =>
                            DropdownMenuItem(value: r.id, child: Text(r.name)),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => roomId = v),
                ),
              ),
              if (room == null)
                Expanded(
                  child: empty(
                    'Chọn phòng có tình trạng Tốt. Thêm phòng và gán người thuê trước.',
                  ),
                )
              else ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      info('Giá thuê lấy từ phòng', money(room.data['price'])),
                      info(
                        'Tiền cọc lấy từ phòng',
                        money(room.data['deposit']),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: EditForm(
                    embedded: true,
                    key: ValueKey(room.id),
                    title: 'Thông tin hợp đồng',
                    action: 'saveContract',
                    id: widget.contract?.id,
                    fixed: {'roomId': room.id},
                    initial:
                        widget.contract?.data ??
                        {
                          'startDate': DateTime.now()
                              .toUtc()
                              .add(const Duration(hours: 7))
                              .toIso8601String()
                              .substring(0, 10),
                        },
                    fields: [
                      const FieldSpec('number', 'Số hợp đồng (duy nhất)'),
                      FieldSpec(
                        'tenantId',
                        'Người đứng hợp đồng',
                        options: {
                          for (final t in ts.where(
                            (t) => !t.archived && t.text('roomId') == room.id,
                          ))
                            t.id: t.name,
                        },
                      ),
                      const FieldSpec('startDate', 'Ngày bắt đầu (YYYY-MM-DD)'),
                      const FieldSpec('endDate', 'Ngày kết thúc (YYYY-MM-DD)'),
                      const FieldSpec(
                        'note',
                        'Điều khoản / ghi chú',
                        required: false,
                      ),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    ),
  );
}
