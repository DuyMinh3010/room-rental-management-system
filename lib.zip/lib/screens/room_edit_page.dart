import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';

class RoomEditPage extends StatelessWidget {
  final Record? room;
  const RoomEditPage({super.key, this.room});
  @override
  Widget build(BuildContext context) => EditForm(
    title: room == null ? 'Thêm phòng' : 'Chỉnh sửa phòng',
    action: 'saveRoom',
    id: room?.id,
    initial: {
      ...?room?.data,
      'condition': room?.condition ?? 'Tốt',
      'billingDay':
          int.tryParse((room?.text('billingDay') ?? '05').split(' ').first) ??
          5,
      'paymentTermDays': room?.data['paymentTermDays'] ?? 5,
      'capacity': room?.data['capacity'] ?? 4,
    },
    fields: const [
      FieldSpec('name', 'Tên phòng'),
      FieldSpec(
        'area',
        'Diện tích (m²)',
        number: true,
        decimal: true,
        min: 0.1,
      ),
      FieldSpec('capacity', 'Số người tối đa', number: true, min: 1, max: 100),
      FieldSpec('price', 'Giá thuê (đ/tháng)', number: true, min: 1),
      FieldSpec('deposit', 'Tiền cọc (đ)', number: true, min: 0),
      FieldSpec(
        'billingDay',
        'Ngày phát hành hóa đơn hàng tháng (1–31)',
        number: true,
        min: 1,
        max: 31,
      ),
      FieldSpec(
        'paymentTermDays',
        'Số ngày được thanh toán kể từ ngày phát hành',
        number: true,
        min: 0,
        max: 60,
      ),
      FieldSpec(
        'condition',
        'Tình trạng phòng',
        options: {'Tốt': 'Tốt', 'Đang sửa': 'Đang sửa'},
      ),
      FieldSpec('description', 'Mô tả', required: false),
    ],
  );
}
