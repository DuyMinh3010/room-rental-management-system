import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'invoice_detail_page.dart';
import 'room_detail_page.dart';

class NotificationPage extends StatelessWidget {
  final bool landlord;
  const NotificationPage({super.key, this.landlord = true});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Thông báo')),
    body: RecordsView(
      collection: 'notifications',
      field: landlord ? 'audience' : 'recipientUid',
      equals: landlord ? 'managers' : store.uid,
      builder: (_, all) => RecordsView(
        collection: 'users/${store.uid}/reads',
        builder: (_, reads) {
          all.sort(
            (a, b) => (b.time('createdAt') ?? DateTime(2000)).compareTo(
              a.time('createdAt') ?? DateTime(2000),
            ),
          );
          final readIds = reads.map((r) => r.id).toSet();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (all.isEmpty) empty('Chưa có thông báo'),
              for (final n in all)
                Card(
                  child: ListTile(
                    leading: Icon(
                      readIds.contains(n.id)
                          ? Icons.notifications_none
                          : Icons.mark_email_unread_outlined,
                      color: blue,
                    ),
                    title: Text(
                      n.text('title'),
                      style: TextStyle(
                        fontWeight: readIds.contains(n.id)
                            ? FontWeight.normal
                            : FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      '${n.text('body')}\n${n.time('createdAt')?.toLocal().toString().substring(0, 16) ?? ''}',
                    ),
                    onTap: () async {
                      try {
                        await store.markRead(n.id);
                      } catch (e) {
                        if (context.mounted) message(context, e.toString());
                      }
                      if (!context.mounted) return;
                      if (n.text('invoiceId').isNotEmpty)
                        await openPage(
                          context,
                          InvoiceDetailPage(
                            invoiceId: n.text('invoiceId'),
                            landlord: landlord,
                          ),
                        );
                      else if (landlord && n.text('roomId').isNotEmpty)
                        await openPage(
                          context,
                          RoomDetailPage(roomId: n.text('roomId')),
                        );
                    },
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}

class NotificationButton extends StatelessWidget {
  final bool landlord;
  const NotificationButton({super.key, this.landlord = true});
  @override
  Widget build(BuildContext context) => RecordsView(
    collection: 'notifications',
    field: landlord ? 'audience' : 'recipientUid',
    equals: landlord ? 'managers' : store.uid,
    builder: (_, notices) => RecordsView(
      collection: 'users/${store.uid}/reads',
      builder: (_, reads) {
        final seen = reads.map((r) => r.id).toSet();
        final count = notices.where((n) => !seen.contains(n.id)).length;
        return IconButton(
          onPressed: () =>
              openPage(context, NotificationPage(landlord: landlord)),
          icon: Badge(
            isLabelVisible: count > 0,
            label: Text('$count'),
            child: const Icon(Icons.notifications_outlined),
          ),
        );
      },
    ),
  );
}
