import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'room_edit_page.dart';
import 'service_page.dart';
import 'tenant_detail_page.dart';
import 'invoice_detail_page.dart';

class RoomDetailPage extends StatelessWidget {
  final String roomId;
  const RoomDetailPage({super.key, required this.roomId});
  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 4,
    child: Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết phòng'),
        bottom: const TabBar(
          tabs: [
            Tab(text: 'Tổng quan'),
            Tab(text: 'Người thuê'),
            Tab(text: 'Dịch vụ'),
            Tab(text: 'Hóa đơn'),
          ],
        ),
      ),
      // Chi tiết chỉ có nút quay lại, không chứa thanh điều hướng dưới.
      body: DocumentView(
        collection: 'rooms',
        id: roomId,
        builder: (room) => TabBarView(
          children: [
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  room.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                box(
                  Column(
                    children: [
                      info('Tình trạng', room.condition),
                      info('Diện tích', '${room.number('area') ?? '—'} m²'),
                      info(
                        'Số người',
                        '${room.number('people') ?? 0}/${room.number('capacity') ?? '—'}',
                      ),
                      info('Giá thuê', money(room.data['price'])),
                      info('Tiền cọc', money(room.data['deposit'])),
                      info('Ngày phát hành', room.text('billingDay')),
                      info(
                        'Hạn thanh toán',
                        '${room.number('paymentTermDays') ?? 5} ngày',
                      ),
                      info('Mô tả', room.text('description')),
                    ],
                  ),
                ),
                FilledButton.icon(
                  onPressed: () => openPage(context, RoomEditPage(room: room)),
                  icon: const Icon(Icons.edit_outlined),
                  label: const Text('Chỉnh sửa phòng'),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Dịch vụ áp dụng',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                RoomServices(room: room, compact: true),
                const SizedBox(height: 12),
                const Text('Ảnh phòng'),
                photos(room),
                OutlinedButton.icon(
                  onPressed: null,
                  icon: const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('Ảnh: chưa hỗ trợ trên Spark'),
                ),
                TextButton(
                  onPressed: () async {
                    if (await confirm(
                          context,
                          'Lưu trữ phòng ${room.name}? Lịch sử hóa đơn vẫn được giữ.',
                        ) &&
                        context.mounted) {
                      await perform(
                        context,
                        () => store.command('archiveRoom', id: roomId),
                        'Đã lưu trữ phòng',
                      );
                    }
                  },
                  child: const Text(
                    'Lưu trữ phòng',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
            RecordsView(
              collection: 'tenants',
              field: 'roomId',
              equals: roomId,
              builder: (_, ts) {
                final tenants = ts.where((t) => !t.archived).toList();
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (tenants.isEmpty)
                      empty('Chưa có người thuê. Vào mục Người thuê để thêm.'),
                    for (final t in tenants)
                      Card(
                        child: ListTile(
                          title: Text(t.name),
                          subtitle: Text(t.text('phone')),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => openPage(
                            context,
                            TenantDetailPage(tenantId: t.id),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                RoomServices(room: room),
                const Divider(),
                const Text(
                  'Nhập chỉ số',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                MeterRoomForm(room: room),
              ],
            ),
            RecordsView(
              collection: 'invoices',
              field: 'roomId',
              equals: roomId,
              builder: (_, bs) {
                bs.sort((a, b) => b.text('period').compareTo(a.text('period')));
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (bs.isEmpty) empty('Chưa có hóa đơn'),
                    for (final b in bs)
                      Card(
                        child: ListTile(
                          title: Text(
                            '${b.text('code', b.id)} · ${b.text('period')}',
                          ),
                          subtitle: Text(
                            '${money(b.data['total'])} · ${label(b.text('status'))}',
                          ),
                          onTap: () => openPage(
                            context,
                            InvoiceDetailPage(invoiceId: b.id),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    ),
  );
}
