import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'invoice_create_page.dart';
import 'invoice_detail_page.dart';

class InvoicePage extends StatefulWidget {
  const InvoicePage({super.key});
  @override
  State<InvoicePage> createState() => _InvoicePageState();
}

class _InvoicePageState extends State<InvoicePage> {
  String filter = 'all', query = '';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Hóa đơn'),
      actions: [
        IconButton(
          onPressed: () => openPage(context, const InvoiceCreatePage()),
          icon: const Icon(Icons.add),
        ),
      ],
    ),
    body: RecordsView(
      collection: 'invoices',
      builder: (_, all) {
        final bills = all
            .where(
              (b) =>
                  (filter == 'all' || b.text('status') == filter) &&
                  '${b.text('roomName')} ${b.text('tenantName')} ${b.text('period')}'
                      .toLowerCase()
                      .contains(query.toLowerCase()),
            )
            .toList();
        bills.sort(
          (a, b) => b.text('issueDate').compareTo(a.text('issueDate')),
        );
        final debt = all
            .where((b) => ['unpaid', 'reported'].contains(b.text('status')))
            .fold<num>(0, (sum, b) => sum + (b.number('total') ?? 0));
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            box(info('Tổng chưa thanh toán', money(debt))),
            const Text(
              'Hóa đơn tự phát hành theo ngày chốt khi bật Tự động trong Tài khoản. Điện/nước dùng chỉ số tháng trước; thiếu chỉ số sẽ chưa phát hành.',
            ),
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(
                hintText: 'Tìm phòng / người thuê / YYYY-MM',
                prefixIcon: Icon(Icons.search),
              ),
            ),
            DropdownButton<String>(
              isExpanded: true,
              value: filter,
              items: [
                const DropdownMenuItem(value: 'all', child: Text('Tất cả')),
                for (final v in ['unpaid', 'reported', 'paid', 'void'])
                  DropdownMenuItem(value: v, child: Text(label(v))),
              ],
              onChanged: (v) => setState(() => filter = v!),
            ),
            if (bills.isEmpty) empty('Chưa có hóa đơn'),
            for (final b in bills)
              Card(
                child: ListTile(
                  title: Text('${b.text('roomName')} · ${b.text('period')}'),
                  subtitle: Text(
                    '${money(b.data['total'])}\n${label(b.text('status'))} · Hạn ${b.text('dueDate')}',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      openPage(context, InvoiceDetailPage(invoiceId: b.id)),
                ),
              ),
          ],
        );
      },
    ),
  );
}
