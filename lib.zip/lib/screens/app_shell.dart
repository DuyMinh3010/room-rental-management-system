import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'room_page.dart';
import 'tenant_list_page.dart';
import 'service_page.dart';
import 'invoice_page.dart';
import 'contract_page.dart';
import 'maintenance_page.dart';
import 'account_page.dart';
import 'notification_page.dart';
import 'invoice_detail_page.dart';

class AppShell extends StatefulWidget {
  final bool landlord;
  const AppShell({super.key, required this.landlord});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int index = 0;
  bool checking = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkBilling());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkBilling();
  }

  Future<void> _checkBilling() async {
    if (!widget.landlord || checking) return;
    checking = true;
    try {
      await store.command('runBilling');
    } catch (e) {
      if (mounted) message(context, 'Chưa kiểm tra được hóa đơn: $e');
    } finally {
      checking = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.landlord) return _tenantView(context);
    final pages = [
      const RoomPage(),
      const TenantListPage(),
      const ServicePage(),
      const InvoicePage(),
      const ContractPage(),
      const MaintenancePage(),
      const AccountPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 42,
        title: const Text('Chủ trọ', style: TextStyle(fontSize: 14)),
        actions: const [NotificationButton()],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        height: 72,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            label: 'Phòng',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            label: 'Người thuê',
          ),
          NavigationDestination(
            icon: Icon(Icons.bolt_outlined),
            label: 'Dịch vụ',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            label: 'Hóa đơn',
          ),
          NavigationDestination(
            icon: Icon(Icons.description_outlined),
            label: 'Hợp đồng',
          ),
          NavigationDestination(
            icon: Icon(Icons.handyman_outlined),
            label: 'Bảo trì',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            label: 'Tài khoản',
          ),
        ],
      ),
    );
  }

  Widget _tenantView(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Hóa đơn của tôi'),
      actions: [
        const NotificationButton(landlord: false),
        IconButton(
          icon: const Icon(Icons.logout),
          onPressed: () async {
            await FirebaseAuth.instance.signOut();
          },
        ),
      ],
    ),
    body: RecordsView(
      collection: 'invoices',
      field: 'recipientUid',
      equals: store.uid,
      builder: (_, all) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Nếu bạn là chủ trọ, UID cần có trong managers với enabled = true. Nếu là người thuê, nhờ chủ trọ liên kết UID tài khoản vào hồ sơ người thuê.',
          ),
          if (all.isEmpty) empty('Chưa có hóa đơn được gửi cho tài khoản này'),
          for (final b in all)
            Card(
              child: ListTile(
                title: Text('${b.text('roomName')} · ${b.text('period')}'),
                subtitle: Text('${b.data['total']}đ · ${b.text('status')}'),
                onTap: () => openPage(
                  context,
                  InvoiceDetailPage(invoiceId: b.id, landlord: false),
                ),
              ),
            ),
        ],
      ),
    ),
  );
}
