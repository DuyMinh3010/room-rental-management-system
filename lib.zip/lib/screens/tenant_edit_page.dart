import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';

class TenantEditPage extends StatelessWidget {
  final Record? tenant;
  const TenantEditPage({super.key, this.tenant});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Người thuê')),
    body: RecordsView(
      collection: 'rooms',
      builder: (_, rs) => EditForm(
        embedded: true,
        title: tenant == null ? 'Thêm người thuê' : 'Sửa người thuê',
        action: 'saveTenant',
        id: tenant?.id,
        initial: tenant?.data ?? const {},
        fields: [
          const FieldSpec('name', 'Họ tên'),
          const FieldSpec('phone', 'Số điện thoại'),
          const FieldSpec('email', 'Email', required: false),
          const FieldSpec('identity', 'CCCD / Passport', required: false),
          FieldSpec(
            'roomId',
            'Phòng đang ở',
            required: false,
            options: {
              '': 'Chưa gán phòng',
              for (final r in rs.where((r) => !r.archived)) r.id: r.name,
            },
          ),
          const FieldSpec('birthday', 'Ngày sinh', required: false),
          const FieldSpec('address', 'Địa chỉ thường trú', required: false),
          const FieldSpec('note', 'Ghi chú', required: false),
        ],
      ),
    ),
  );
}
