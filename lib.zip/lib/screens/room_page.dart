import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'room_detail_page.dart';
import 'room_edit_page.dart';

class RoomPage extends StatefulWidget {
  const RoomPage({super.key});
  @override
  State<RoomPage> createState() => _RoomPageState();
}

class _RoomPageState extends State<RoomPage> {
  String query = '', filter = 'Tất cả';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Danh sách phòng'),
      actions: [
        TextButton(
          onPressed: () => openPage(context, const RoomEditPage()),
          child: const Text('+ Thêm'),
        ),
      ],
    ),
    body: RecordsView(
      collection: 'rooms',
      builder: (_, all) {
        final rooms = all.where((r) => !r.archived).toList()
          ..sort((a, b) => a.name.compareTo(b.name));
        return RecordsView(
          collection: 'contracts',
          builder: (_, contracts) {
            final day = DateTime.now()
                .toUtc()
                .add(const Duration(hours: 7))
                .toIso8601String()
                .substring(0, 10);
            bool rented(Record room) => contracts.any(
              (c) =>
                  c.text('roomId') == room.id &&
                  c.text('status') == 'active' &&
                  c.text('startDate').compareTo(day) <= 0 &&
                  c.text('endDate').compareTo(day) >= 0,
            );
            final shown = rooms
                .where(
                  (r) =>
                      r.name.toLowerCase().contains(
                        query.trim().toLowerCase(),
                      ) &&
                      (filter == 'Tất cả' ||
                          filter == 'Đang thuê' && rented(r) ||
                          filter == 'Trống' && !rented(r) ||
                          r.condition == filter),
                )
                .toList();
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                box(
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('Tổng: ${rooms.length}'),
                      Text('Đang thuê: ${rooms.where(rented).length}'),
                      Text(
                        'Đang sửa: ${rooms.where((r) => r.condition == 'Đang sửa').length}',
                      ),
                    ],
                  ),
                ),
                TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: const InputDecoration(
                    hintText: 'Tìm kiếm phòng...',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final v in [
                      'Tất cả',
                      'Đang thuê',
                      'Trống',
                      'Tốt',
                      'Đang sửa',
                    ])
                      ChoiceChip(
                        label: Text(v),
                        selected: filter == v,
                        onSelected: (_) => setState(() => filter = v),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                if (shown.isEmpty)
                  empty('Chưa có phòng hoặc không khớp bộ lọc'),
                for (final r in shown)
                  Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: r.condition == 'Đang sửa'
                            ? Colors.orange.shade100
                            : Colors.blue.shade50,
                        child: const Icon(Icons.meeting_room_outlined),
                      ),
                      title: Text(
                        r.name,
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        '${money(r.data['price'])}/tháng\n${r.number('area') ?? '—'} m² · ${r.number('people') ?? 0} người\n${r.condition} · ${rented(r) ? 'Đang thuê' : 'Chưa có hợp đồng hiệu lực'}',
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () =>
                          openPage(context, RoomDetailPage(roomId: r.id)),
                    ),
                  ),
              ],
            );
          },
        );
      },
    ),
  );
}
