import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import '../services/document_service.dart';

class ContractDetailPage extends StatelessWidget {
  final String contractId;
  const ContractDetailPage({super.key, required this.contractId});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Chi tiết hợp đồng')),
    body: DocumentView(
      collection: 'contracts',
      id: contractId,
      builder: (c) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (c.text('roomId').isEmpty || c.text('tenantId').isEmpty)
            box(
              const Text(
                'Hợp đồng cũ chưa liên kết đủ dữ liệu. Đối chiếu dữ liệu cũ và tạo hợp đồng chuẩn mới nếu thiếu liên kết. Không xóa lịch sử hợp đồng.',
              ),
            ),
          box(
            Column(
              children: [
                info('Số hợp đồng', c.text('number', c.text('id', c.id))),
                info('Phòng', c.text('roomName', c.text('room'))),
                info('Người thuê', c.text('tenantName', c.text('name'))),
                info('Bắt đầu', c.text('startDate', c.text('start'))),
                info('Kết thúc', c.text('endDate', c.text('end'))),
                info('Giá thuê đã chốt', money(c.data['rent'])),
                info('Tiền cọc đã chốt', money(c.data['deposit'])),
                info('Trạng thái', label(c.text('status'))),
                info('Điều khoản', c.text('note')),
              ],
            ),
          ),
          const Text(
            'Giá và tiền cọc được sao chép từ phòng lúc lập hợp đồng. Thay giá phòng về sau không đổi hợp đồng đã chốt.',
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => perform(
              context,
              () => DocumentService.printRecord(c, contract: true),
              'Đã mở bản in',
            ),
            icon: const Icon(Icons.print_outlined),
            label: const Text('In / lưu PDF hợp đồng'),
          ),
          if (['active', 'scheduled'].contains(c.text('status')))
            TextButton(
              onPressed: () async {
                if (await confirm(
                      context,
                      'Kết thúc/hủy hợp đồng này? Hóa đơn còn nợ phải được xử lý trước.',
                    ) &&
                    context.mounted)
                  await perform(
                    context,
                    () => store.command('endContract', id: contractId),
                  );
              },
              child: const Text(
                'Kết thúc hợp đồng',
                style: TextStyle(color: Colors.red),
              ),
            ),
        ],
      ),
    ),
  );
}
