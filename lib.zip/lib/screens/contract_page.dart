import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'contract_edit_page.dart';
import 'contract_detail_page.dart';

class ContractPage extends StatefulWidget {
  const ContractPage({super.key});
  @override
  State<ContractPage> createState() => _ContractPageState();
}

class _ContractPageState extends State<ContractPage> {
  String query = '', filter = 'all';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Hợp đồng'),
      actions: [
        IconButton(
          onPressed: () => openPage(context, const ContractEditPage()),
          icon: const Icon(Icons.add),
        ),
      ],
    ),
    body: RecordsView(
      collection: 'contracts',
      builder: (_, all) {
        final contracts = all
            .where(
              (c) =>
                  '${c.text('number', c.text('id', c.id))} ${c.text('tenantName', c.text('name'))} ${c.text('roomName', c.text('room'))}'
                      .toLowerCase()
                      .contains(query.toLowerCase()) &&
                  (filter == 'all' || c.text('status') == filter),
            )
            .toList();
        contracts.sort(
          (a, b) => b.text('startDate').compareTo(a.text('startDate')),
        );
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(
                hintText: 'Tìm số hợp đồng / phòng / người thuê',
                prefixIcon: Icon(Icons.search),
              ),
            ),
            DropdownButton<String>(
              isExpanded: true,
              value: filter,
              items: [
                const DropdownMenuItem(value: 'all', child: Text('Tất cả')),
                for (final v in [
                  'active',
                  'scheduled',
                  'ended',
                  'expired',
                  'cancelled',
                ])
                  DropdownMenuItem(value: v, child: Text(label(v))),
              ],
              onChanged: (v) => setState(() => filter = v!),
            ),
            if (contracts.isEmpty) empty('Chưa có hợp đồng'),
            for (final c in contracts)
              Card(
                child: ListTile(
                  title: Text(c.text('number', c.text('id', c.id))),
                  subtitle: Text(
                    '${c.text('roomName', c.text('room'))} · ${c.text('tenantName', c.text('name'))}\n${label(c.text('status'))}',
                  ),
                  onTap: () =>
                      openPage(context, ContractDetailPage(contractId: c.id)),
                ),
              ),
          ],
        );
      },
    ),
  );
}
