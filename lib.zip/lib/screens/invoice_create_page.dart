import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'invoice_detail_page.dart';

class InvoiceCreatePage extends StatefulWidget {
  const InvoiceCreatePage({super.key});
  @override
  State<InvoiceCreatePage> createState() => _InvoiceCreatePageState();
}

class _InvoiceCreatePageState extends State<InvoiceCreatePage> {
  String? roomId;
  final period = periodOf();
  Map<String, dynamic>? preview;
  Future<void> _preview() async {
    if (roomId == null) return;
    await perform(context, () async {
      final data = await store.command(
        'previewInvoice',
        args: {'roomId': roomId, 'period': period},
      );
      if (mounted) setState(() => preview = data);
    }, 'Đã tính hóa đơn từ dữ liệu Firebase');
  }

  Future<void> _issue() async {
    if (roomId == null) return;
    if (!await confirm(
      context,
      'Phát hành hóa đơn và gửi vào hộp thư tài khoản người thuê đã liên kết?',
    ))
      return;
    if (!mounted) return;
    await perform(context, () async {
      final result = await store.command(
        'issueInvoice',
        args: {'roomId': roomId, 'period': period},
      );
      if (mounted)
        setState(() => preview = {...?preview, 'issuedId': result['id']});
    }, 'Đã xử lý phát hành hóa đơn');
    if (mounted && preview?['issuedId'] != null)
      await openPage(
        context,
        InvoiceDetailPage(invoiceId: preview!['issuedId'] as String),
      );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tính và phát hành hóa đơn')),
    body: RecordsView(
      collection: 'rooms',
      builder: (_, all) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          info('Kỳ tiền phòng', period),
          info('Kỳ sử dụng điện/nước', previousPeriod(period)),
          DropdownButtonFormField<String>(
            initialValue: roomId,
            decoration: const InputDecoration(labelText: 'Phòng'),
            items: all
                .where((r) => !r.archived)
                .map((r) => DropdownMenuItem(value: r.id, child: Text(r.name)))
                .toList(),
            onChanged: (v) => setState(() {
              roomId = v;
              preview = null;
            }),
          ),
          const SizedBox(height: 16),
          const Text(
            'Tiền phòng lấy từ hợp đồng còn hiệu lực. Dịch vụ lấy theo phòng đã áp dụng và chỉ số đã lưu. Đơn giá và số tiền được app đọc lại từ Firestore và tính khi phát hành.',
          ),
          if (roomId != null) ...[
            const SizedBox(height: 16),
            const Text(
              'Phụ phí',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            RecordsView(
              collection: 'extras',
              field: 'roomId',
              equals: roomId,
              builder: (_, xs) => Column(
                children: [
                  for (final x in xs.where((x) => x.text('period') == period))
                    ListTile(
                      title: Text(x.text('reason')),
                      subtitle: Text(money(x.data['amount'])),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await perform(
                            context,
                            () => store.command('deleteExtra', id: x.id),
                          );
                          if (mounted) setState(() => preview = null);
                        },
                      ),
                    ),
                ],
              ),
            ),
            OutlinedButton(
              onPressed: () async {
                await openPage(
                  context,
                  EditForm(
                    title: 'Thêm phụ phí · $period',
                    action: 'saveExtra',
                    fixed: {'roomId': roomId, 'period': period},
                    fields: const [
                      FieldSpec('reason', 'Ghi rõ vấn đề/lý do phụ phí'),
                      FieldSpec(
                        'amount',
                        'Số tiền phụ phí (đ)',
                        number: true,
                        min: 1,
                      ),
                    ],
                  ),
                );
                if (mounted) setState(() => preview = null);
              },
              child: const Text('+ Phụ phí có lý do'),
            ),
            FilledButton(
              onPressed: _preview,
              child: const Text('Tự tính / Xem trước'),
            ),
          ],
          if (preview != null) ...[
            const SizedBox(height: 16),
            box(
              Column(
                children: [
                  info('Người thuê', '${preview!['tenantName']}'),
                  for (final row in preview!['lines'] as List)
                    info(
                      '${row['name']} (${row['quantity']} × ${money(row['unitPrice'])})',
                      money(row['amount']),
                    ),
                  const Divider(),
                  info('Tổng cộng', money(preview!['total'])),
                  info('Hạn thanh toán', '${preview!['dueDate']}'),
                ],
              ),
            ),
            if (preview!['delivered'] != true)
              const Text(
                'Chưa liên kết tài khoản người thuê. Hóa đơn vẫn được tạo nhưng chưa thể gửi tới người thuê. Vào Người thuê để liên kết UID Authentication.',
                style: TextStyle(color: Colors.orange),
              ),
            FilledButton(
              onPressed: _issue,
              child: const Text('Phát hành và gửi hóa đơn'),
            ),
          ],
        ],
      ),
    ),
  );
}
