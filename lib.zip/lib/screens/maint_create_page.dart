import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';

class MaintCreatePage extends StatelessWidget {
  final Record? maintenance;
  const MaintCreatePage({super.key, this.maintenance});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Yêu cầu bảo trì')),
    body: RecordsView(
      collection: 'rooms',
      builder: (_, rooms) => EditForm(
        embedded: true,
        title: maintenance == null ? 'Thêm yêu cầu' : 'Cập nhật bảo trì',
        action: 'saveMaintenance',
        id: maintenance?.id,
        initial: maintenance?.data ?? {'status': 'new', 'cost': 0},
        fields: [
          FieldSpec(
            'roomId',
            'Phòng',
            options: {
              for (final r in rooms.where((r) => !r.archived)) r.id: r.name,
            },
          ),
          const FieldSpec('title', 'Vấn đề cần xử lý'),
          const FieldSpec('description', 'Mô tả chi tiết'),
          const FieldSpec(
            'status',
            'Trạng thái',
            options: {
              'new': 'Mới tiếp nhận',
              'working': 'Đang xử lý',
              'done': 'Hoàn thành',
              'cancelled': 'Đã hủy',
            },
          ),
          const FieldSpec('cost', 'Chi phí bảo trì (đ)', number: true, min: 0),
        ],
      ),
    ),
  );
}
