import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../widgets/common.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tài khoản & cài đặt')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        box(
          Column(
            children: [
              info('Email', FirebaseAuth.instance.currentUser?.email ?? ''),
              info('UID', store.uid),
              TextButton(
                onPressed: () =>
                    Clipboard.setData(ClipboardData(text: store.uid)),
                child: const Text('Sao chép UID'),
              ),
            ],
          ),
        ),
        ListTile(
          leading: const Icon(Icons.settings_outlined),
          title: const Text('Thông tin chủ trọ, ngân hàng, tự động hóa'),
          onTap: () => openPage(context, const SettingsPage()),
        ),
        ListTile(
          leading: const Icon(Icons.play_circle_outline),
          title: const Text('Chạy kiểm tra hóa đơn và quá hạn ngay'),
          subtitle: const Text(
            'Bản Spark: kiểm tra khi mở app hoặc bấm nút này',
          ),
          onTap: () => perform(context, () async {
            final result = await store.command('runBilling');
            if (context.mounted)
              message(
                context,
                'Mới: ${result['created']} · Đã có: ${result['existing']} · Chưa đủ dữ liệu: ${result['blocked']} · Nhắc quá hạn: ${result['late']}',
              );
          }, 'Đã chạy kiểm tra; xem mục Thông báo để biết phòng thiếu dữ liệu'),
        ),
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: const Text('Đổi mật khẩu'),
          onTap: () => openPage(context, const PasswordPage()),
        ),
        ListTile(
          leading: const Icon(Icons.logout),
          title: const Text('Đăng xuất'),
          onTap: () async {
            await FirebaseAuth.instance.signOut();
          },
        ),
      ],
    ),
  );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool? auto;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Cài đặt chủ trọ')),
    body: RecordsView(
      collection: 'settings',
      builder: (_, all) {
        final settings = all.where((r) => r.id == 'landlord').firstOrNull;
        final enabled = auto ?? settings?.data['autoBilling'] == true;
        return Column(
          children: [
            SwitchListTile(
              title: const Text('Tạo hóa đơn đến kỳ khi mở app'),
              subtitle: const Text(
                'Chỉ chạy khi chủ trọ mở app; không chạy khi app đóng',
              ),
              value: enabled,
              onChanged: (v) => setState(() => auto = v),
            ),
            Expanded(
              child: EditForm(
                embedded: true,
                title: 'Thông tin',
                action: 'saveSettings',
                id: 'landlord',
                initial: settings?.data ?? const {},
                fixed: {'autoBilling': enabled},
                fields: const [
                  FieldSpec('name', 'Họ tên chủ trọ'),
                  FieldSpec('phone', 'Số điện thoại'),
                  FieldSpec('address', 'Địa chỉ', required: false),
                  FieldSpec('bankName', 'Tên ngân hàng', required: false),
                  FieldSpec('bankAccount', 'Số tài khoản', required: false),
                  FieldSpec('bankHolder', 'Tên chủ tài khoản', required: false),
                ],
              ),
            ),
          ],
        );
      },
    ),
  );
}

class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key});
  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final current = TextEditingController(),
      password = TextEditingController(),
      confirmPassword = TextEditingController();
  @override
  void dispose() {
    current.dispose();
    password.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Đổi mật khẩu')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(
          controller: current,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Mật khẩu hiện tại'),
        ),
        TextField(
          controller: password,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Mật khẩu mới (ít nhất 6 ký tự)',
          ),
        ),
        TextField(
          controller: confirmPassword,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Nhập lại mật khẩu mới'),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () {
            if (password.text.length < 6 ||
                password.text != confirmPassword.text) {
              message(context, 'Mật khẩu chưa đủ dài hoặc chưa khớp');
              return;
            }
            perform(context, () async {
              final user = FirebaseAuth.instance.currentUser!;
              await user.reauthenticateWithCredential(
                EmailAuthProvider.credential(
                  email: user.email!,
                  password: current.text,
                ),
              );
              await user.updatePassword(password.text);
            }, 'Đã đổi mật khẩu');
          },
          child: const Text('Đổi mật khẩu'),
        ),
      ],
    ),
  );
}
