import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'maint_create_page.dart';

class MaintenancePage extends StatelessWidget {
  const MaintenancePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Bảo trì'),
      actions: [
        IconButton(
          onPressed: () => openPage(context, const MaintCreatePage()),
          icon: const Icon(Icons.add),
        ),
      ],
    ),
    body: RecordsView(
      collection: 'maintenance',
      builder: (_, all) => RecordsView(
        collection: 'rooms',
        builder: (_, rooms) {
          all.sort(
            (a, b) => (b.time('createdAt') ?? DateTime(2000)).compareTo(
              a.time('createdAt') ?? DateTime(2000),
            ),
          );
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (all.isEmpty) empty('Chưa có yêu cầu bảo trì'),
              for (final m in all)
                Card(
                  child: ListTile(
                    title: Text(m.text('title')),
                    subtitle: Text(
                      '${rooms.where((r) => r.id == m.text('roomId')).firstOrNull?.name ?? m.text('roomId')} · ${label(m.text('status'))}',
                    ),
                    onTap: () => openPage(
                      context,
                      MaintenanceDetailPage(maintenanceId: m.id),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}

class MaintenanceDetailPage extends StatelessWidget {
  final String maintenanceId;
  const MaintenanceDetailPage({super.key, required this.maintenanceId});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Chi tiết bảo trì')),
    body: DocumentView(
      collection: 'maintenance',
      id: maintenanceId,
      builder: (m) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          box(
            Column(
              children: [
                info('Vấn đề', m.text('title')),
                info('Mô tả', m.text('description')),
                info('Trạng thái', label(m.text('status'))),
                info('Chi phí', money(m.data['cost'])),
              ],
            ),
          ),
          photos(m),
          FilledButton(
            onPressed: () => openPage(context, MaintCreatePage(maintenance: m)),
            child: const Text('Cập nhật xử lý'),
          ),
          OutlinedButton(
            onPressed: null,
            child: const Text('Tải ảnh: chưa hỗ trợ trên Spark'),
          ),
          const Text(
            'Chi phí bảo trì không tự cộng vào hóa đơn. Nếu người thuê phải chi trả, thêm phụ phí có lý do khi lập hóa đơn.',
          ),
        ],
      ),
    ),
  );
}
