import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';

class ServiceEditPage extends StatelessWidget {
  final Record? service;
  const ServiceEditPage({super.key, this.service});
  @override
  Widget build(BuildContext context) => EditForm(
    title: service == null ? 'Thêm dịch vụ' : 'Sửa dịch vụ',
    action: 'saveService',
    id: service?.id,
    initial: service?.data ?? const {'mode': 'meter'},
    fields: const [
      FieldSpec('name', 'Tên dịch vụ'),
      FieldSpec(
        'mode',
        'Cách tính',
        options: {
          'meter': 'Theo chỉ số',
          'room': 'Theo phòng/tháng',
          'person': 'Theo người/tháng',
        },
      ),
      FieldSpec('price', 'Đơn giá (đ)', number: true, min: 0),
      FieldSpec('unit', 'Đơn vị (kWh, m³, tháng, người...)'),
      FieldSpec('note', 'Ghi chú', required: false),
    ],
  );
}
