import 'package:flutter/material.dart';

import '../models/record.dart';
import '../widgets/common.dart';
import 'service_edit_page.dart';

class ServicePage extends StatefulWidget {
  const ServicePage({super.key});
  @override
  State<ServicePage> createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  String query = '';
  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 2,
    child: Scaffold(
      appBar: AppBar(
        title: const Text('Dịch vụ'),
        bottom: const TabBar(
          tabs: [
            Tab(text: 'Dịch vụ'),
            Tab(text: 'Nhập chỉ số'),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => openPage(context, const ServiceEditPage()),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: TabBarView(
        children: [
          RecordsView(
            collection: 'services',
            builder: (_, all) {
              final services =
                  all
                      .where(
                        (s) =>
                            !s.archived &&
                            s.name.toLowerCase().contains(query.toLowerCase()),
                      )
                      .toList()
                    ..sort((a, b) => a.name.compareTo(b.name));
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  TextField(
                    onChanged: (v) => setState(() => query = v),
                    decoration: const InputDecoration(
                      hintText: 'Tìm dịch vụ',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (services.isEmpty) empty('Chưa có dịch vụ'),
                  for (final s in services)
                    Card(
                      child: ListTile(
                        title: Text(s.name),
                        subtitle: Text(
                          '${label(s.text('mode'))} · ${money(s.data['price'])}/${s.text('unit')}',
                        ),
                        onTap: () =>
                            openPage(context, ServiceEditPage(service: s)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            if (await confirm(
                                  context,
                                  'Xóa dịch vụ ${s.name}? Dịch vụ phải được bỏ khỏi các phòng trước.',
                                ) &&
                                context.mounted)
                              await perform(
                                context,
                                () => store.command('archiveService', id: s.id),
                                'Đã xóa dịch vụ khỏi danh mục',
                              );
                          },
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          RecordsView(
            collection: 'rooms',
            builder: (_, rs) {
              final rooms = rs.where((r) => !r.archived).toList();
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const Text(
                    'Nhập chỉ số tháng sử dụng. Hóa đơn tháng sau sẽ lấy chỉ số của tháng này.',
                  ),
                  if (rooms.isEmpty) empty('Tạo phòng ở Trang chủ trước'),
                  for (final r in rooms)
                    Card(
                      child: ListTile(
                        title: Text(r.name),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => openPage(
                          context,
                          Scaffold(
                            appBar: AppBar(
                              title: Text('Nhập chỉ số · ${r.name}'),
                            ),
                            body: ListView(
                              padding: const EdgeInsets.all(16),
                              children: [MeterRoomForm(room: r)],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    ),
  );
}

// Dùng chung tại Chi tiết phòng > Dịch vụ và Tổng quan.
class RoomServices extends StatelessWidget {
  final Record room;
  final bool compact;
  const RoomServices({super.key, required this.room, this.compact = false});
  Future<void> _assign(BuildContext context, List<Record> all) async {
    final picked = room.strings('serviceIds').toSet();
    final result = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, refresh) => AlertDialog(
          title: const Text('Dịch vụ áp dụng cho phòng'),
          content: SizedBox(
            width: 400,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (all.isEmpty)
                    const Text('Tạo dịch vụ trong danh mục trước'),
                  for (final s in all)
                    CheckboxListTile(
                      title: Text(s.name),
                      subtitle: Text(
                        '${money(s.data['price'])}/${s.text('unit')} · ${label(s.text('mode'))}',
                      ),
                      value: picked.contains(s.id),
                      onChanged: (v) => refresh(() {
                        v == true ? picked.add(s.id) : picked.remove(s.id);
                      }),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Hủy'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, picked.toList()),
              child: const Text('Lưu'),
            ),
          ],
        ),
      ),
    );
    if (result != null && context.mounted)
      await perform(
        context,
        () => store.command(
          'assignServices',
          args: {'roomId': room.id, 'serviceIds': result},
        ),
      );
  }

  @override
  Widget build(BuildContext context) => RecordsView(
    collection: 'services',
    builder: (_, all) {
      final active = all.where((s) => !s.archived).toList(),
          assigned = all
              .where((s) => room.strings('serviceIds').contains(s.id))
              .toList();
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (assigned.isEmpty) empty('Chưa áp dụng dịch vụ nào'),
          for (final s in assigned)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(s.name),
              subtitle: Text('${label(s.text('mode'))} · ${s.text('unit')}'),
              trailing: Text(money(s.data['price'])),
            ),
          OutlinedButton(
            onPressed: () => _assign(context, active),
            child: const Text('Chọn / bỏ dịch vụ cho phòng'),
          ),
        ],
      );
    },
  );
}

class MeterRoomForm extends StatefulWidget {
  final Record room;
  const MeterRoomForm({super.key, required this.room});
  @override
  State<MeterRoomForm> createState() => _MeterRoomFormState();
}

class _MeterRoomFormState extends State<MeterRoomForm> {
  String period = periodOf();
  @override
  Widget build(BuildContext context) => Column(
    children: [
      TextFormField(
        initialValue: period,
        decoration: const InputDecoration(labelText: 'Tháng sử dụng (YYYY-MM)'),
        onChanged: (v) {
          if (RegExp(r'^\d{4}-(0[1-9]|1[0-2])$').hasMatch(v))
            setState(() => period = v);
        },
      ),
      RecordsView(
        collection: 'services',
        builder: (_, all) {
          final services = all
              .where(
                (s) =>
                    !s.archived &&
                    s.text('mode') == 'meter' &&
                    widget.room.strings('serviceIds').contains(s.id),
              )
              .toList();
          return RecordsView(
            collection: 'meters',
            field: 'roomId',
            equals: widget.room.id,
            builder: (_, meters) => Column(
              children: [
                if (services.isEmpty)
                  empty('Phòng chưa áp dụng dịch vụ theo chỉ số'),
                for (final s in services)
                  Builder(
                    builder: (context) {
                      final saved = meters
                          .where(
                            (m) =>
                                m.text('period') == period &&
                                m.text('serviceId') == s.id,
                          )
                          .firstOrNull;
                      final prev = meters
                          .where(
                            (m) =>
                                m.text('period') == previousPeriod(period) &&
                                m.text('serviceId') == s.id,
                          )
                          .firstOrNull;
                      return Card(
                        child: ListTile(
                          title: Text(s.name),
                          subtitle: Text(
                            saved == null
                                ? 'Chưa nhập'
                                : '${saved.number('previous')} → ${saved.number('current')} · ${saved.number('usage')} ${s.text('unit')}',
                          ),
                          trailing: const Icon(Icons.edit_outlined),
                          onTap: () => openPage(
                            context,
                            MeterInputPage(
                              room: widget.room,
                              service: s,
                              period: period,
                              meter: saved,
                              previous: prev,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
              ],
            ),
          );
        },
      ),
    ],
  );
}

class MeterInputPage extends StatelessWidget {
  final Record room, service;
  final Record? meter, previous;
  final String period;
  const MeterInputPage({
    super.key,
    required this.room,
    required this.service,
    required this.period,
    this.meter,
    this.previous,
  });
  @override
  Widget build(BuildContext context) => EditForm(
    title: '${room.name} · ${service.name} · $period',
    action: 'saveMeter',
    initial: {
      'previous': previous?.data['current'] ?? meter?.data['previous'] ?? '',
      'current': meter?.data['current'] ?? '',
    },
    fixed: {'roomId': room.id, 'serviceId': service.id, 'period': period},
    fields: [
      FieldSpec(
        'previous',
        previous == null
            ? 'Chỉ số cũ (kỳ đầu nhập thực tế)'
            : 'Chỉ số cũ (lấy từ kỳ trước: ${previous!.data['current']})',
        number: true,
        readOnly: previous != null,
        decimal: true,
        min: 0,
      ),
      const FieldSpec(
        'current',
        'Chỉ số mới',
        number: true,
        decimal: true,
        min: 0,
      ),
    ],
  );
}
