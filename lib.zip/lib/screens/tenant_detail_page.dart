import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'tenant_edit_page.dart';
import 'contract_detail_page.dart';

class TenantDetailPage extends StatelessWidget {
  final String tenantId;
  const TenantDetailPage({super.key, required this.tenantId});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Chi tiết người thuê')),
    body: DocumentView(
      collection: 'tenants',
      id: tenantId,
      builder: (t) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          box(
            Column(
              children: [
                info('Họ tên', t.name),
                info('Số điện thoại', t.text('phone')),
                info('Email', t.text('email')),
                info('CCCD', t.text('identity')),
                info('Ngày sinh', t.text('birthday')),
                info('Địa chỉ', t.text('address')),
                info('Ghi chú', t.text('note')),
                info('UID nhận hóa đơn', t.text('authUid')),
              ],
            ),
          ),
          FilledButton(
            onPressed: () => openPage(context, TenantEditPage(tenant: t)),
            child: const Text('Chỉnh sửa'),
          ),
          OutlinedButton(
            onPressed: () async {
              final controller = TextEditingController(text: t.text('authUid'));
              final authUid = await showDialog<String>(
                context: context,
                builder: (c) => AlertDialog(
                  title: const Text('Liên kết tài khoản nhận hóa đơn'),
                  content: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      labelText: 'UID sao chép từ Authentication → Users',
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('Hủy'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(c, controller.text.trim()),
                      child: const Text('Liên kết'),
                    ),
                  ],
                ),
              );
              controller.dispose();
              if (authUid != null && context.mounted)
                await perform(
                  context,
                  () => store.command(
                    'linkTenantAccount',
                    id: tenantId,
                    args: {'authUid': authUid},
                  ),
                );
            },
            child: const Text('Liên kết tài khoản nhận hóa đơn'),
          ),
          const SizedBox(height: 16),
          const Text('Hợp đồng'),
          RecordsView(
            collection: 'contracts',
            field: 'tenantId',
            equals: tenantId,
            builder: (_, cs) => Column(
              children: [
                for (final c in cs)
                  ListTile(
                    title: Text(c.text('number', c.id)),
                    subtitle: Text(c.text('status')),
                    onTap: () =>
                        openPage(context, ContractDetailPage(contractId: c.id)),
                  ),
              ],
            ),
          ),
          TextButton(
            onPressed: () async {
              if (await confirm(
                    context,
                    'Lưu trữ người thuê? Không xóa lịch sử hợp đồng.',
                  ) &&
                  context.mounted)
                await perform(
                  context,
                  () => store.command('archiveTenant', id: tenantId),
                );
            },
            child: const Text(
              'Lưu trữ người thuê',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    ),
  );
}
